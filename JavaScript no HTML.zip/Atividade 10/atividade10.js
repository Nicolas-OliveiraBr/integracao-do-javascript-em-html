const headerTitulo = document.querySelector('header')
headerTitulo.id = 'header_id'
headerTitulo.insertAdjacentHTML('afterbegin', '<h1 class="classe1">Título Legal :D</h1>')

const mainDiv = document.querySelector('main')
mainDiv.insertAdjacentHTML('afterbegin', '<div class="div1"></div>')

const tituloMain = document.querySelector(".div1")
tituloMain.insertAdjacentHTML('afterbegin', '<h2>Um novo texto :D</h2> <p>Agora um parágrafo :O</p>')

const divMain = document.querySelector('main')
divMain.insertAdjacentHTML('afterend', '<div class="div2"></div>')

const tituloMain2 = document.querySelector(".div2")
tituloMain2.insertAdjacentHTML("afterbegin", '<h2>Um outro texto ;-;</h2> <p>E agora mais outro parágrafo :/</p>')